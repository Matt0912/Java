public abstract class Entity {
    abstract String getName();
    abstract String getDescription();

}
